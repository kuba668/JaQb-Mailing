﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace Mailing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void wyslijBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Uwaga! Program zadziała tylko gdy serer nadawcy to gmail.com", "Uwaga!",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            string mailNadawcy = nadawcaTxt.Text;
            string nazwa =nazwaTxt.Text;
            string mailOdbiorcy = odbiorcaTxt.Text;
            string temat = tematTxt.Text;
            string treśćMaila = tekstTxt.Text;
            string login = loginTxt.Text;
            string hasło = hasłoTxt.Text;
            
            if (temat==""||treśćMaila=="")
            {
                MessageBox.Show("Wysyłasz wiadomość bez tematu i treści", "Brak tematu i treści", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (temat == "")
            {
                MessageBox.Show("Wysyłasz wiadomość bez tematu", "Brak tematu", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (treśćMaila == "")
            {
                MessageBox.Show("Wysyłasz wiadomość bez treści", "Brak treści", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (mailNadawcy ==""||nazwa==""||mailOdbiorcy==""||login==""||hasło=="")
            {
                MessageBox.Show("Nie podano wszystkich danych", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
               

            }
            else
            {
                var message = new MailMessage();
                message.From = new MailAddress(mailNadawcy, nazwa);
                message.To.Add(new MailAddress(mailOdbiorcy));
                message.Subject = temat;
                message.Body = $"{treśćMaila} " +
                    $"Mail wysłany przez JaQb Mailing";
                var smtp = new SmtpClient("smtp.gmail.com");
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(login, hasło);
                smtp.EnableSsl = true;
                smtp.Port = 587;
                smtp.Send(message);

                MessageBox.Show($"Wysłano pomyślnie maila do {mailOdbiorcy}", "Wysłano", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

           
            


        }
    }
}
