﻿namespace Mailing
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nadawcaTxt = new System.Windows.Forms.TextBox();
            this.tekstTxt = new System.Windows.Forms.RichTextBox();
            this.nazwaTxt = new System.Windows.Forms.TextBox();
            this.odbiorcaTxt = new System.Windows.Forms.TextBox();
            this.tematTxt = new System.Windows.Forms.TextBox();
            this.loginTxt = new System.Windows.Forms.TextBox();
            this.hasłoTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.wyslijBtn = new System.Windows.Forms.Button();
            this.wyczyscBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "JaQb Mailing";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mail nadawcy";
            // 
            // nadawcaTxt
            // 
            this.nadawcaTxt.Location = new System.Drawing.Point(12, 77);
            this.nadawcaTxt.Name = "nadawcaTxt";
            this.nadawcaTxt.Size = new System.Drawing.Size(461, 22);
            this.nadawcaTxt.TabIndex = 2;
            // 
            // tekstTxt
            // 
            this.tekstTxt.Location = new System.Drawing.Point(506, 77);
            this.tekstTxt.Name = "tekstTxt";
            this.tekstTxt.Size = new System.Drawing.Size(461, 253);
            this.tekstTxt.TabIndex = 3;
            this.tekstTxt.Text = "";
            // 
            // nazwaTxt
            // 
            this.nazwaTxt.Location = new System.Drawing.Point(12, 121);
            this.nazwaTxt.Name = "nazwaTxt";
            this.nazwaTxt.Size = new System.Drawing.Size(461, 22);
            this.nazwaTxt.TabIndex = 4;
            // 
            // odbiorcaTxt
            // 
            this.odbiorcaTxt.Location = new System.Drawing.Point(12, 165);
            this.odbiorcaTxt.Name = "odbiorcaTxt";
            this.odbiorcaTxt.Size = new System.Drawing.Size(461, 22);
            this.odbiorcaTxt.TabIndex = 5;
            // 
            // tematTxt
            // 
            this.tematTxt.Location = new System.Drawing.Point(12, 209);
            this.tematTxt.Name = "tematTxt";
            this.tematTxt.Size = new System.Drawing.Size(461, 22);
            this.tematTxt.TabIndex = 6;
            // 
            // loginTxt
            // 
            this.loginTxt.Location = new System.Drawing.Point(12, 264);
            this.loginTxt.Name = "loginTxt";
            this.loginTxt.Size = new System.Drawing.Size(461, 22);
            this.loginTxt.TabIndex = 7;
            // 
            // hasłoTxt
            // 
            this.hasłoTxt.Location = new System.Drawing.Point(12, 308);
            this.hasłoTxt.Name = "hasłoTxt";
            this.hasłoTxt.PasswordChar = '*';
            this.hasłoTxt.Size = new System.Drawing.Size(461, 22);
            this.hasłoTxt.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Nazwa nadawcy";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "Mail odbiorcy";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Temat wiadomości";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(503, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Treść wiadomości";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Login do poczty";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 16);
            this.label8.TabIndex = 14;
            this.label8.Text = "Hasło do poczty";
            // 
            // wyslijBtn
            // 
            this.wyslijBtn.Location = new System.Drawing.Point(12, 352);
            this.wyslijBtn.Name = "wyslijBtn";
            this.wyslijBtn.Size = new System.Drawing.Size(461, 126);
            this.wyslijBtn.TabIndex = 15;
            this.wyslijBtn.Text = "Wyślij";
            this.wyslijBtn.UseVisualStyleBackColor = true;
            this.wyslijBtn.Click += new System.EventHandler(this.wyslijBtn_Click);
            // 
            // wyczyscBtn
            // 
            this.wyczyscBtn.Location = new System.Drawing.Point(506, 352);
            this.wyczyscBtn.Name = "wyczyscBtn";
            this.wyczyscBtn.Size = new System.Drawing.Size(461, 126);
            this.wyczyscBtn.TabIndex = 16;
            this.wyczyscBtn.Text = "Wyczyść";
            this.wyczyscBtn.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 493);
            this.Controls.Add(this.wyczyscBtn);
            this.Controls.Add(this.wyslijBtn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.hasłoTxt);
            this.Controls.Add(this.loginTxt);
            this.Controls.Add(this.tematTxt);
            this.Controls.Add(this.odbiorcaTxt);
            this.Controls.Add(this.nazwaTxt);
            this.Controls.Add(this.tekstTxt);
            this.Controls.Add(this.nadawcaTxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "JaQb Mailing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nadawcaTxt;
        private System.Windows.Forms.RichTextBox tekstTxt;
        private System.Windows.Forms.TextBox nazwaTxt;
        private System.Windows.Forms.TextBox odbiorcaTxt;
        private System.Windows.Forms.TextBox tematTxt;
        private System.Windows.Forms.TextBox loginTxt;
        private System.Windows.Forms.TextBox hasłoTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button wyslijBtn;
        private System.Windows.Forms.Button wyczyscBtn;
    }
}

